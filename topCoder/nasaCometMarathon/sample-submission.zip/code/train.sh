python3 train.py $*
