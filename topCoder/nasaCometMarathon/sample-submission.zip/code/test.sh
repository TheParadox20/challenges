python3 test.py $1 $2
